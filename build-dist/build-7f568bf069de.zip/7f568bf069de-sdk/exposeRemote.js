
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/7f568bf069de-sdk/static/js/remoteEntry.js'
    